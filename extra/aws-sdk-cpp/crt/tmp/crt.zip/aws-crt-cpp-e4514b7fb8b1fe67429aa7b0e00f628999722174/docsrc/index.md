## Welcome to awscrt's documentation!

C++ bindings for the AWS Common Runtime.

Github: https://github.com/awslabs/aws-crt-cpp
