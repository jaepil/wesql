This directory is used to store build artifacts (tarballs and source) for a locally
built copy of libcrypto, either from OpenSSL, LibreSSL or BoringSSL.

See the s2n [Build Guide](../docs/BUILD.md#building-with-a-specific-libcrypto) for more details.
